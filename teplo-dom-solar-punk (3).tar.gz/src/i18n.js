import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  ru: {
    translation: {
      title: "ТеплоДом",
      subtitle: "Сколько тепла, денег и CO₂ вы сэкономите в Нарыне",
      next: "Далее",
      back: "Назад",
      calculate: "Рассчитать",
      restart: "Новый расчёт",
      share: "Поделиться картинкой",
      step: "Шаг",
      of: "из",
      houseType: "Тип дома",
      area: "Площадь дома (м²)",
      fuel: "Основное топливо",
      selectTips: "Выберите меры (можно несколько)",
      results: "Ваши результаты",
      costNow: "Затраты сейчас",
      costSave: "Экономия за зиму",
      co2Now: "CO₂ сейчас",
      co2Save: "Снижение CO₂",
      som: "сом",
      kg: "кг",
      payback: "Окупаемость",
      years: "лет",
      topTips: "Топ советы",
      range: "диапазон",
      now: "Сейчас",
      after: "После",
      theme: "Тема",
      light: "Светлая",
      dark: "Тёмная",
      lang: "Язык",
    }
  },
  ky: {
    translation: {
      title: "ЖылуҮй",
      subtitle: "Нарында канча жылуулук, акча жана CO₂ үнөмдөйсүз",
      next: "Кийинки",
      back: "Артка",
      calculate: "Эсептөө",
      restart: "Жаңы эсептөө",
      share: "Сүрөт менен бөлүшүү",
      step: "Кадам",
      of: "дан",
      houseType: "Үй түрү",
      area: "Үйдүн аянты (м²)",
      fuel: "Негизги отун",
      selectTips: "Чараларды тандаңыз (бир нечеси)",
      results: "Сиздин жыйынтыктар",
      costNow: "Азыркы чыгым",
      costSave: "Кышкы үнөмдөө",
      co2Now: "Азыркы CO₂",
      co2Save: "CO₂ азайуу",
      som: "сом",
      kg: "кг",
      payback: "Өзүн актоо",
      years: "жыл",
      topTips: "Мыкты кеңештер",
      range: "диапазон",
      now: "Азыр",
      after: "Кийин",
      theme: "Тема",
      light: "Жарык",
      dark: "Караңгы",
      lang: "Тил",
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'ru',
    fallbackLng: 'ru',
    interpolation: { escapeValue: false },
  });

export default i18n;
