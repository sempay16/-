import { FUELS, HOUSE_TYPES, TIPS, REGION, MAX_COMBINED } from './data.js';

/**
 * Расчёт базового тепла (кВт·ч за сезон)
 * Q = площадь × удельный расход × климатический коэффициент
 */
export function calculateHeatDemand(area, houseTypeId) {
  const house = HOUSE_TYPES.find(h => h.id === houseTypeId);
  if (!house) return 0;
  return area * house.heatDemandKwhPerM2 * REGION.climateCoeff;
}

/**
 * Расход топлива T = Q / (теплотворность × КПД)
 */
export function calculateFuelAmount(heatDemandKwh, fuelId) {
  const fuel = FUELS.find(f => f.id === fuelId);
  if (!fuel) return 0;
  return heatDemandKwh / (fuel.calorificKwhPerUnit * fuel.efficiency);
}

/**
 * Стоимость топлива
 */
export function calculateFuelCost(fuelAmount, fuelId) {
  const fuel = FUELS.find(f => f.id === fuelId);
  if (!fuel) return 0;
  return fuelAmount * fuel.pricePerUnit;
}

/**
 * CO2 выбросы
 */
export function calculateCO2(fuelAmount, fuelId) {
  const fuel = FUELS.find(f => f.id === fuelId);
  if (!fuel) return 0;
  return fuelAmount * fuel.co2KgPerUnit;
}

/**
 * Суммарная экономия с учётом взаимодействия (не простая сумма %)
 */
export function calculateCombinedSavings(selectedTipIds) {
  if (!selectedTipIds.length) return { min: 0, max: 0 };
  let remainingMin = 1;
  let remainingMax = 1;
  selectedTipIds.forEach(id => {
    const tip = TIPS.find(t => t.id === id);
    if (tip) {
      remainingMin *= (1 - tip.savingsMin);
      remainingMax *= (1 - tip.savingsMax);
    }
  });
  const min = Math.min(1 - remainingMin, MAX_COMBINED);
  const max = Math.min(1 - remainingMax, MAX_COMBINED);
  return { min, max };
}

/**
 * Полный расчёт для выбранных советов
 */
export function calculateResults(area, houseTypeId, fuelId, selectedTipIds) {
  const heatNow = calculateHeatDemand(area, houseTypeId);
  const fuelNow = calculateFuelAmount(heatNow, fuelId);
  const costNow = calculateFuelCost(fuelNow, fuelId);
  const co2Now = calculateCO2(fuelNow, fuelId);

  const { min: saveMin, max: saveMax } = calculateCombinedSavings(selectedTipIds);
  const heatAfterMin = heatNow * (1 - saveMax); // больше экономия → меньше тепла
  const heatAfterMax = heatNow * (1 - saveMin);

  const fuelAfterMin = calculateFuelAmount(heatAfterMin, fuelId);
  const fuelAfterMax = calculateFuelAmount(heatAfterMax, fuelId);
  const costAfterMin = calculateFuelCost(fuelAfterMin, fuelId);
  const costAfterMax = calculateFuelCost(fuelAfterMax, fuelId);
  const co2AfterMin = calculateCO2(fuelAfterMin, fuelId);
  const co2AfterMax = calculateCO2(fuelAfterMax, fuelId);

  const tipsDetails = selectedTipIds.map(id => {
    const tip = TIPS.find(t => t.id === id);
    const saveMid = (tip.savingsMin + tip.savingsMax) / 2;
    const annualSaveSom = costNow * saveMid;
    const paybackYears = tip.costSom > 0 ? tip.costSom / annualSaveSom : 0;
    return {
      ...tip,
      annualSaveSom: Math.round(annualSaveSom),
      paybackYears: paybackYears > 0 ? paybackYears.toFixed(1) : "0",
    };
  }).sort((a, b) => a.paybackYears - b.paybackYears);

  return {
    heatNow: Math.round(heatNow),
    fuelNow: Number(fuelNow.toFixed(2)),
    costNow: Math.round(costNow),
    co2Now: Math.round(co2Now),
    saveMin: Math.round(saveMin * 100),
    saveMax: Math.round(saveMax * 100),
    costSaveMin: Math.round(costNow - costAfterMax),
    costSaveMax: Math.round(costNow - costAfterMin),
    co2SaveMin: Math.round(co2Now - co2AfterMax),
    co2SaveMax: Math.round(co2Now - co2AfterMin),
    tipsDetails,
    fuel: FUELS.find(f => f.id === fuelId),
  };
}

// Простые примеры для проверки (запустите в консоли или тестах)
export const EXAMPLES = [
  {
    name: "Саманный дом 80 м², уголь, 3 совета",
    input: { area: 80, house: "adobe", fuel: "coal", tips: ["ceiling", "sealing", "behavior"] },
  },
  {
    name: "Кирпичный 100 м², дрова, все советы",
    input: { area: 100, house: "brick", fuel: "wood", tips: TIPS.map(t => t.id) },
  },
  {
    name: "Панельный 60 м², электричество",
    input: { area: 60, house: "panel", fuel: "electricity", tips: ["windows", "ceiling"] },
  },
];

export function runExamples() {
  return EXAMPLES.map(ex => ({
    ...ex,
    result: calculateResults(ex.input.area, ex.input.house, ex.input.fuel, ex.input.tips),
  }));
}
