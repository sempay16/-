import { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { HOUSE_TYPES, FUELS, TIPS } from './data.js';
import { calculateResults } from './calc.js';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import html2canvas from 'html2canvas';

export default function App() {
  const { t, i18n } = useTranslation();
  const [dark, setDark] = useState(false);
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    houseType: 'adobe',
    area: 80,
    fuel: 'coal',
    tips: ['ceiling', 'sealing', 'behavior'],
  });
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const resultRef = useRef(null);

  const toggleTheme = () => {
    setDark(!dark);
    document.documentElement.classList.toggle('dark');
  };

  const toggleLang = () => {
    i18n.changeLanguage(i18n.language === 'ru' ? 'ky' : 'ru');
  };

  const handleNext = () => {
    if (step === 1 && (!form.area || form.area < 20 || form.area > 500)) {
      setError(i18n.language === 'ru' ? 'Введите площадь от 20 до 500 м²' : '20–500 м² киргизиңиз');
      return;
    }
    setError('');
    if (step < 4) setStep(step + 1);
    else {
      const res = calculateResults(Number(form.area), form.houseType, form.fuel, form.tips);
      setResults(res);
      setStep(5);
    }
  };

  const toggleTip = (id) => {
    setForm(prev => ({
      ...prev,
      tips: prev.tips.includes(id)
        ? prev.tips.filter(t => t !== id)
        : [...prev.tips, id],
    }));
  };

  const shareImage = async () => {
    if (!resultRef.current) return;
    const canvas = await html2canvas(resultRef.current, { backgroundColor: dark ? '#022c22' : '#ecfdf5', scale: 2 });
    const link = document.createElement('a');
    link.download = 'teplo-dom-result.png';
    link.href = canvas.toDataURL();
    link.click();
  };

  const chartData = results ? [
    { name: t('now'), cost: results.costNow, co2: results.co2Now },
    { name: t('after'), cost: results.costNow - results.costSaveMax, co2: results.co2Now - results.co2SaveMax },
  ] : [];

  return (
    <div className={`min-h-screen ${dark ? 'dark' : ''}`}>
      <header className="flex justify-between items-center p-4 max-w-4xl mx-auto">
        <div>
          <h1 className="text-3xl font-bold text-solar-green dark:text-solar-lime">{t('title')}</h1>
          <p className="text-sm text-emerald-700 dark:text-emerald-300">{t('subtitle')}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={toggleLang} className="px-3 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-900 text-sm font-medium">
            {i18n.language.toUpperCase()}
          </button>
          <button onClick={toggleTheme} className="px-3 py-1 rounded-lg bg-yellow-100 dark:bg-yellow-900 text-sm font-medium">
            {dark ? t('light') : t('dark')}
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-4 pb-12">
        {step < 5 && (
          <div className="card">
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span>{t('step')} {step} {t('of')} 4</span>
                <span>{Math.round((step / 4) * 100)}%</span>
              </div>
              <div className="h-2 bg-emerald-200 dark:bg-emerald-800 rounded-full">
                <div className="h-2 bg-solar-green rounded-full transition-all" style={{ width: `${(step / 4) * 100}%` }} />
              </div>
            </div>

            {error && <div className="mb-4 p-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-lg text-sm">{error}</div>}

            {step === 1 && (
              <div className="space-y-4">
                <label className="block font-medium">{t('houseType')}</label>
                <div className="grid grid-cols-1 gap-2">
                  {HOUSE_TYPES.map(h => (
                    <button key={h.id} onClick={() => setForm({...form, houseType: h.id})}
                      className={`p-4 rounded-xl border-2 text-left transition ${form.houseType === h.id ? 'border-solar-green bg-emerald-50 dark:bg-emerald-900' : 'border-emerald-200 dark:border-emerald-700'}`}>
                      {i18n.language === 'ru' ? h.nameRu : h.nameKy}
                    </button>
                  ))}
                </div>
                <label className="block font-medium mt-4">{t('area')}</label>
                <input type="number" value={form.area} onChange={e => setForm({...form, area: e.target.value})}
                  className="w-full p-4 text-lg rounded-xl border border-emerald-300 dark:border-emerald-700 dark:bg-emerald-950" min="20" max="500" />
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <label className="block font-medium">{t('fuel')}</label>
                <div className="grid grid-cols-1 gap-2">
                  {FUELS.map(f => (
                    <button key={f.id} onClick={() => setForm({...form, fuel: f.id})}
                      className={`p-4 rounded-xl border-2 text-left transition ${form.fuel === f.id ? 'border-solar-green bg-emerald-50 dark:bg-emerald-900' : 'border-emerald-200 dark:border-emerald-700'}`}>
                      {i18n.language === 'ru' ? f.nameRu : f.nameKy}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-3">
                <label className="block font-medium">{t('selectTips')}</label>
                {TIPS.map(tip => (
                  <button key={tip.id} onClick={() => toggleTip(tip.id)}
                    className={`w-full p-4 rounded-xl border-2 text-left transition ${form.tips.includes(tip.id) ? 'border-solar-green bg-emerald-50 dark:bg-emerald-900' : 'border-emerald-200 dark:border-emerald-700'}`}>
                    <div className="font-semibold">{i18n.language === 'ru' ? tip.titleRu : tip.titleKy}</div>
                    <div className="text-sm opacity-80 mt-1">{i18n.language === 'ru' ? tip.descRu : tip.descKy}</div>
                    <div className="text-xs mt-1 text-solar-green">
                      {Math.round(tip.savingsMin*100)}–{Math.round(tip.savingsMax*100)}% · {tip.costSom} {t('som')}
                    </div>
                  </button>
                ))}
              </div>
            )}

            {step === 4 && (
              <div className="space-y-3 text-sm">
                <p><strong>{t('houseType')}:</strong> {HOUSE_TYPES.find(h => h.id === form.houseType)?.[i18n.language === 'ru' ? 'nameRu' : 'nameKy']}</p>
                <p><strong>{t('area')}:</strong> {form.area} м²</p>
                <p><strong>{t('fuel')}:</strong> {FUELS.find(f => f.id === form.fuel)?.[i18n.language === 'ru' ? 'nameRu' : 'nameKy']}</p>
                <p><strong>Советы:</strong> {form.tips.length}</p>
              </div>
            )}

            <div className="flex gap-3 mt-8">
              {step > 1 && <button onClick={() => setStep(step-1)} className="btn-secondary flex-1">{t('back')}</button>}
              <button onClick={handleNext} className="btn-primary flex-1">
                {step === 4 ? t('calculate') : t('next')}
              </button>
            </div>
          </div>
        )}

        {step === 5 && results && (
          <div ref={resultRef} className="space-y-6">
            <div className="card text-center">
              <h2 className="text-2xl font-bold mb-4">{t('results')}</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-100 dark:bg-emerald-900 rounded-xl">
                  <div className="text-sm opacity-70">{t('costNow')}</div>
                  <div className="text-3xl font-bold text-solar-green">{results.costNow.toLocaleString()} {t('som')}</div>
                </div>
                <div className="p-4 bg-yellow-100 dark:bg-yellow-900 rounded-xl">
                  <div className="text-sm opacity-70">{t('costSave')}</div>
                  <div className="text-3xl font-bold text-amber-600">{results.costSaveMin.toLocaleString()}–{results.costSaveMax.toLocaleString()} {t('som')}</div>
                </div>
                <div className="p-4 bg-emerald-100 dark:bg-emerald-900 rounded-xl">
                  <div className="text-sm opacity-70">{t('co2Now')}</div>
                  <div className="text-2xl font-bold">{results.co2Now.toLocaleString()} {t('kg')}</div>
                </div>
                <div className="p-4 bg-yellow-100 dark:bg-yellow-900 rounded-xl">
                  <div className="text-sm opacity-70">{t('co2Save')}</div>
                  <div className="text-2xl font-bold">{results.co2SaveMin.toLocaleString()}–{results.co2SaveMax.toLocaleString()} {t('kg')}</div>
                </div>
              </div>
              <p className="mt-4 text-sm opacity-70">Экономия тепла: {results.saveMin}–{results.saveMax}%</p>
            </div>

            <div className="card">
              <h3 className="font-bold mb-4">Сейчас vs После</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={chartData}>
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="cost" name={t('som')} fill="#10b981" />
                  <Bar dataKey="co2" name={t('kg')} fill="#fbbf24" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="card">
              <h3 className="font-bold mb-4">{t('topTips')}</h3>
              {results.tipsDetails.slice(0, 3).map(tip => (
                <div key={tip.id} className="mb-4 p-4 bg-emerald-50 dark:bg-emerald-900/50 rounded-xl">
                  <div className="font-semibold">{i18n.language === 'ru' ? tip.titleRu : tip.titleKy}</div>
                  <div className="text-sm mt-1">{i18n.language === 'ru' ? tip.descRu : tip.descKy}</div>
                  <div className="text-sm mt-2 text-solar-green">
                    ~{tip.annualSaveSom.toLocaleString()} {t('som')}/год · {t('payback')}: {tip.paybackYears} {t('years')}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-3">
              <button onClick={shareImage} className="btn-primary flex-1">{t('share')}</button>
              <button onClick={() => { setStep(1); setResults(null); }} className="btn-secondary flex-1">{t('restart')}</button>
            </div>
          </div>
        )}
      </main>

      <footer className="text-center text-xs opacity-60 py-6">
        ТеплоДом / ЖылуҮй · SolarPunk Hackathon · Оценки, не официальные данные
      </footer>
    </div>
  );
}
