/**
 * ТеплоДом / ЖылуҮй — все коэффициенты и константы
 * Регион демо: Нарын (холодная зима)
 * ВАЖНО: все значения — ОЦЕНКИ. Проверьте по актуальным источникам.
 */

export const REGION = {
  name: "Нарын",
  nameKy: "Нарын",
  climateCoeff: 1.35, // оценка: Нарын холоднее среднего по КР
  heatingMonths: 6,
};

export const HOUSE_TYPES = [
  {
    id: "brick",
    nameRu: "Кирпичный",
    nameKy: "Кирпич",
    heatDemandKwhPerM2: 380, // оценка
  },
  {
    id: "adobe",
    nameRu: "Саманный (глинобитный)",
    nameKy: "Саман",
    heatDemandKwhPerM2: 480, // оценка — хуже теплоизоляция
  },
  {
    id: "panel",
    nameRu: "Панельный",
    nameKy: "Панель",
    heatDemandKwhPerM2: 420, // оценка
  },
];

export const FUELS = [
  {
    id: "coal",
    nameRu: "Уголь",
    nameKy: "Көмүр",
    calorificKwhPerUnit: 6500, // кВт·ч/т оценка
    pricePerUnit: 6500, // сом/т оценка Нарын
    co2KgPerUnit: 2400, // кг CO2/т оценка
    unitRu: "тонн",
    unitKy: "тонна",
    efficiency: 0.55, // КПД печи оценка
  },
  {
    id: "wood",
    nameRu: "Дрова",
    nameKy: "Отун",
    calorificKwhPerUnit: 1800, // кВт·ч/м³ оценка
    pricePerUnit: 4200, // сом/м³ оценка
    co2KgPerUnit: 900, // кг CO2/м³ (прямые, биогенный)
    unitRu: "м³",
    unitKy: "м³",
    efficiency: 0.50,
  },
  {
    id: "electricity",
    nameRu: "Электричество",
    nameKy: "Электр",
    calorificKwhPerUnit: 1,
    pricePerUnit: 2.5, // сом/кВт·ч оценка
    co2KgPerUnit: 0.4, // кг/кВт·ч оценка сетки КР
    unitRu: "кВт·ч",
    unitKy: "кВт·саат",
    efficiency: 0.95,
  },
  {
    id: "gas",
    nameRu: "Газ",
    nameKy: "Газ",
    calorificKwhPerUnit: 10, // кВт·ч/м³ оценка
    pricePerUnit: 15, // сом/м³ оценка
    co2KgPerUnit: 2.0, // кг/м³ оценка
    unitRu: "м³",
    unitKy: "м³",
    efficiency: 0.85,
  },
];

export const TIPS = [
  {
    id: "ceiling",
    titleRu: "Утепление потолка / чердака",
    titleKy: "Шыпты / чатырды жылуулоо",
    descRu: "Слой 15–20 см опилок, соломы или минваты. Самый эффективный и дешёвый шаг.",
    descKy: "15–20 см талкан, саман же минвата. Эң натыйжалуу жана арзан кадам.",
    savingsMin: 0.15,
    savingsMax: 0.22,
    costSom: 8000,
  },
  {
    id: "windows",
    titleRu: "Уплотнение и утепление окон",
    titleKy: "Терезелерди тыгыздоо жана жылуулоо",
    descRu: "Пластиковые окна, уплотнители, плотные шторы и плёнка на зиму.",
    descKy: "Пластик терезелер, тыгыздыктар, калың перделер жана кышка пленка.",
    savingsMin: 0.08,
    savingsMax: 0.12,
    costSom: 25000,
  },
  {
    id: "walls",
    titleRu: "Утепление стен",
    titleKy: "Дубалдарды жылуулоо",
    descRu: "Внешнее утепление глиной/соломой или минватой. Снижает теплопотери через стены.",
    descKy: "Тышкы жылуулоо чопо/саман же минвата менен.",
    savingsMin: 0.12,
    savingsMax: 0.20,
    costSom: 18000,
  },
  {
    id: "floor",
    titleRu: "Утепление пола",
    titleKy: "Полду жылуулоо",
    descRu: "Подполье, слой утеплителя под полом или ковры + теплоизоляция.",
    descKy: "Полдун астына жылуулоо же килемдер.",
    savingsMin: 0.08,
    savingsMax: 0.14,
    costSom: 12000,
  },
  {
    id: "sealing",
    titleRu: "Герметизация щелей и двери",
    titleKy: "Жарактарды жана эшикти тыгыздоо",
    descRu: "Заделка щелей, уплотнители на дверях, тамбур. Быстро и дёшево.",
    descKy: "Жарактарды жабуу, эшикке тыгыздык, тамбур.",
    savingsMin: 0.05,
    savingsMax: 0.10,
    costSom: 3000,
  },
  {
    id: "behavior",
    titleRu: "Поведенческие меры",
    titleKy: "Жүрүм-турумдук чаралар",
    descRu: "Закрывать двери в нежилые комнаты, не перегревать, использовать заслонки печи.",
    descKy: "Жашабаган бөлмөлөрдүн эшигин жабуу, мештин тосмосун колдонуу.",
    savingsMin: 0.05,
    savingsMax: 0.12,
    costSom: 0,
  },
];

export const MAX_COMBINED = 0.45; // оценка максимальной суммарной экономии
